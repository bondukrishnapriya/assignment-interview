let homeEl = document.getElementById("home");
let contentEl = document.getElementById("content")